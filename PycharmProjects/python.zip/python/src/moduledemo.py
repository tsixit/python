import textformat

textformat.souligner("Module importé !")
textformat.encadrer("Module importé !")
print(textformat)

import textformat as t

t.souligner("Module renommé !")
t.encadrer("Module renommé !")

from textformat import souligner, encadrer as e, pizza

souligner("Importation de la fonction seule.")
e("Fonction renommée !")
print(pizza)

from textformat import *

espacer("Fonction importée par l'étoile.")

import restaurants

restaurants.affiche_restaurants()

import restaurants.principal

restaurants.principal.run()

from restaurants import principal

principal.run()

from restaurants.principal import run

run()

import restaurants.commun.calcul

print(restaurants.commun.calcul.addition(4, 5))

from restaurants import addition

print(addition(5, 6))

import sys

# sys.path.append('/home/lphan/PycharmProjects/formation/lib')

# $ export PYTHONPATH=/home/lphan/PycharmProjects/formation/lib

# setuptools pour créer monpackage.tar.gz ou monpackage.zip
# pip install monpackage.tar.gz

print(sys.path)

import unmodulededans

print(unmodulededans.division(10, 3))
