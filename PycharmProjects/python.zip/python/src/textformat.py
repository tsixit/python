def souligner(texte):
    print(texte)
    print('=' * len(texte))


def encadrer(texte):
    print('#' * (len(texte)+4))
    print('#', texte, '#')
    print('#' * (len(texte)+4))


pizza = 5


def espacer(texte):
    caracteres = list(texte)
    # print(caracteres)
    print(' '.join(caracteres))


if __name__ == '__main__':
    print(__name__)
    espacer("Hello World!")
