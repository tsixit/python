<?php

# php -S 0.0.0.0:8000 viewer.php
# php -S 0.0.0.0:12345 viewer.php

# $base_route = '/toulouse/src';
$base_route = '/src';

function forbidden() {
    header('HTTP/1.0 403 Forbidden');
    echo "Forbidden :-(";
}

$route = rtrim($_SERVER["REQUEST_URI"], '/');
# var_dump($route);

if (substr($route, 0, strlen($base_route)) != $base_route) {
    forbidden();
    return true;
}

$extensions = array(
    'php' => 'php',
    'py' => 'python',
    'html' => 'html',
    'css' => 'css',
    'js' => 'javascript',
    'po' => 'po',
    'phtml' => 'phtml',
    'sql' => 'sql'
);

function open_html()
{
    echo <<<HTML
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>Viewer</title>
    </head>
    <body>
HTML;
}

function close_html()
{
    echo '</body></html>';
}

function excluded($item)
{
    # echo "<p>item = $item</p>";
    if (!$item) return false;
    if ($item[0] === '.') return true;
    return false;
}

function excluded_path($path)
{
    $items = explode('/', $path);
    $excluded = array_filter($items, 'excluded');
    if ($excluded) {
        return true;
    }
    return false;
}

$working_directory = dirname(__FILE__);

# var_dump($_SERVER);

# $path = substr($route, strlen($base_route));
$path = urldecode(substr($route, strlen($base_route)));
# var_dump($path);

$full_path = "$working_directory/$path";
# var_dump($full_path);

$file_parts = pathinfo($full_path);

if (excluded_path($full_path)) {
    # open_html();
    # echo "Interdit :-(";
    # close_html();
    forbidden();
    return true;
}

if (!file_exists($full_path)) {
    header("HTTP/1.0 404 Not Found");
    echo "Not found :-(";
    echo $full_path;
    return true;
}

# } elseif (is_dir($full_path)) {
if (is_dir($full_path)) {

    header("Content-Type: text/html; charset=utf-8");

    open_html();

    $items = scandir($full_path);

    echo "<ul>";
    foreach( $items as $item ) {
        if (excluded($item)) continue;
        echo "<li><a href='$route/$item'>$item</a></li>";
    }
    echo "</ul>";

    close_html();

    return true;

} elseif (isset($file_parts['extension']) && array_key_exists($file_parts['extension'], $extensions)) {

    # if (preg_match("/\.png$/", $full_path)) {

    header("Content-Type: text/html; charset=utf-8");

    open_html();

    $class = $extensions[$file_parts['extension']];
    $c = file_get_contents($full_path);

    echo "<pre><code class='$class'>";
    echo htmlspecialchars($c);
    echo '</pre></code>';

    echo '<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.12.0/styles/agate.min.css">';
    echo '<script src="//cdnjs.cloudflare.com/ajax/libs/highlight.js/9.12.0/highlight.min.js"></script>';
    echo '<script>hljs.initHighlightingOnLoad();</script>';

    close_html();

    return true;

} else {

    # $type = mime_content_type($full_path);

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $type = finfo_file($finfo, $full_path);
    finfo_close($finfo);

    header("Content-type: $type");

    $c = file_get_contents($full_path);
    echo $c;

    return true;

}

?>
