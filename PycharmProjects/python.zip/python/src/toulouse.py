votes = {
    "L'oncle Pom": 0,
    "Aux délices du Liban": 0,
    "Le Yéti": 0
}

# 1) L'oncle Pom : 0
# 2) Aux délices du Liban : 0
# 3) Le Yéti : 0
# q) Quitter
# Votre choix : 1
#
# 1) L'oncle Pom : 1
# 2) Aux délices du Liban : 0
# 3) Le Yéti : 0
# q) Quitter
# Votre choix : 1
#
# 1) L'oncle Pom : 2
# 2) Aux délices du Liban : 0
# 3) Le Yéti : 0
# q) Quitter
# Votre choix : 2
#
# 1) L'oncle Pom : 2
# 2) Aux délices du Liban : 1
# 3) Le Yéti : 0
# q) Quitter
# Votre choix : q

# print(votes)
# print(list(votes.keys()))
restaurants = list(votes.keys())
print(restaurants)

while True:
    for i, restaurant in enumerate(restaurants, 1):
        print("{}) {} : {}".format(i, restaurant, votes[restaurant]))
    print("q) Quitter")

    reponse = input("Votre choix : ")
    print(repr(reponse))

    if reponse == 'q':
        break

    restaurant = restaurants[int(reponse)-1]
    print(restaurant)
    votes[restaurant] += 1
    print(votes)
