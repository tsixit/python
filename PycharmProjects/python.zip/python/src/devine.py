nombre = 7

# 1) Demander à l'utilisateur d'entrer un nombre, tant qu'il n'a pas deviné notre nombre.
# 2) Si le nombre entré est trop grand, afficher "Moins !", s'il est trop petit, afficher "Plus !"

n = None
while n != nombre:
    reponse = input("Entrer un nombre : ")
    if reponse.isdecimal():
        n = int(reponse)
        if n > nombre:
            print("Moins !")
        elif n < nombre:
            print("Plus !")
    else:
        print("*** Vous avez écrit n'importe quoi !")

print("Bravo !")
