from six.moves import input

password = 'parapluie'

reponse = input("Entrer le prix HT de votre produit : ")
# reponse = raw_input("Entrer le prix HT de votre produit : ")  # en Python 2
print(reponse)
print(type(reponse))
print(repr(reponse))
prix_ht = float(reponse)

# 1) Demander le taux de TVA du produit en pourcentage.

reponse2 = input("Entrer le taux de TVA de votre produit : ")
# reponse2 = raw_input("Entrer le taux de TVA de votre produit : ")  # en Python 2
tva = float(reponse2)

# 2) Calculer et afficher le prix TTC du produit.

prix_ttc = prix_ht + prix_ht * tva / 100
print(prix_ttc)
