from datetime import date

aujourdhui = date.today()
print(aujourdhui)
print(aujourdhui.year)
print(aujourdhui.month)
print(aujourdhui.day)

# 1) Demander l'année de naissance de l'utilisateur
# 2) Demander le mois de naissance de l'utilisateur
# 3) Demander le jour de naissance de l'utilisateur
# 4) Déterminer et afficher l'âge de l'utilisateur

annee = int(input("Année de naissance : "))
mois = int(input("Mois de naissance : "))
jour = int(input("Jour de naissance : "))

age = aujourdhui.year - annee
if aujourdhui.month < mois or (aujourdhui.month == mois and aujourdhui.day < jour):
    age = age - 1
print(age)
