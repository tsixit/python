# coding: utf-8

from __future__ import division, print_function

1 + 1
print(1 + 1)
print("Hello World!")
print    (      "Hello World!"                    )
print(1 + 2 * 3)
print((1 + 2) * 3)
print(5 - 2)
print(10 / 3)  # attention : division entière en Python 2
print(10.0 / 3)
print(11 % 3)  # % = modulo = reste de la division entière
print(5 ** 2)
print(round(6.9))
print(round(6.12345, 2))

x = 3
print(x)

largeur = 20
print(largeur)
hauteur = 5 * 9
print(hauteur)
aire = largeur * hauteur
print(aire)

# print(n)

print('abc')
print("Je vais à l'école.")
print("Ça s'appelle une \"pomme\".")
print("- Python\n- Ruby\n- Perl")  # \n = new line = retour à la ligne
print("Colonne 1\tColonne 2\tColonne 3")
print('C:\\nvidia')
print(r'C:\nicolas\toto\nvidia')  # r = raw
print("""\
"DAWAN Paris" :
  11, rue Antoine Bourdelle
  75015 Paris\
""")
print('===')
print('''
On peut également faire ça avec les apostrophes !
On peut également faire ça avec les apostrophes !
On peut également faire ça avec les apostrophes !
''')

print("Hello " + "World!")
print('=' * 70)

# Le slicing (tranchage) avec les chaînes de caractères
# =====================================================

mot = 'Python'
print(mot[0])
print(mot[5])
print(mot[-1])
print(mot[-2])
print(mot[-6])
print(mot[0:2])  # slicing
print(mot[2:5])
print(mot[:2])
print(mot[2:])
print(mot[-2:])
# print(mot[42])  # IndexError: string index out of range
print(mot[4:42])
print(mot[42:])

phrase = "Hello zorld!"
# phrase[6] = 'W'  # TypeError: 'str' object does not support item assignment
# Les chaînes de caractères sont immuables (immutable)
phrase2 = phrase[:6] + 'W' + phrase[7:]
print(phrase2)

print(len(phrase))
print(len('é'))
print(len(u'é'))  # u = unicode

maVariableFlottante = 2.3  # CamelCase
ma_variable_flottante = 2.3  # snake_case

print(1.1 + 1.1 + 1.1)

from decimal import Decimal

prix = Decimal('1.1')
print(prix + prix + prix)
print(Decimal('10') / Decimal('3'))

# Conversion de type
# ==================

print(type(ma_variable_flottante))
print(type(aire))
print(type(phrase))

print("Superficie du terrain : " + str(aire))
print(123 + int("456"))
print(123.456 + float("789.101112"))

# Interpolation de chaînes de caractères
# ======================================

nom = 'Damien'
age = 30
print("Je m'appelle " + nom + " et j'ai " + str(age) + " ans.")
print("Je m'appelle %s." % nom)  # obsolète
print("Je m'appelle %s et j'ai %d ans." % (nom, age))  # obsolète
# %s = string
# %d = int
# %f = float
print("Je m'appelle {} et j'ai {} ans.".format(nom, age))
motif = "Je m'appelle {} et j'ai {} ans."
print(motif.format(nom, age))

print("Flottant : {:.2f}".format(ma_variable_flottante))

jour = 5
mois = 3
annee = 2018

motif = "Nous sommes le {:02d}/{:02d}/{}"
print(motif.format(jour, mois, annee))

motif = "Today is {1:02d}/{0:02d}/{2}"
print(motif.format(jour, mois, annee))

motif = "Today is {month:02d}/{day:02d}/{year}"
print(motif.format(day=jour, month=mois, year=annee))

from datetime import date

d = date(annee, mois, jour)
print(d)
print(type(d))
print(d.year)
print(d.month)
print(d.day)

# Les tests
# =========

jour_du_mois = 31
if jour_du_mois == 31:
    print("Il faut payer les employés !")
    print("Et dépêche-toi s'il te plaît, on n'a pas toute la journée !")

print("Suite du programme...")

if jour_du_mois == 31:
    pass

pass
pass
pass

print("Je vais continuer mon programme tranquillement...")

age = 20
if age < 18:
    print("Vous n'êtes pas autorisé à visiter ce site.")
    print("Veuillez partir d'ici immédiatement s'il vous plaît.")
else:
    print("Soyez le bienvenu.")

print(age >= 18)
print(age <= 18)
print(age != 18)

majeur = False
majeur = True
print(type(majeur))
majeur = age >= 18
if majeur:
    print("Vous pouvez visiter ce site.")

nom = 'Nicolas'
if nom == 'Nicolas':
    print("Bienvenue monsieur l'administrateur du site.")
elif nom == 'Damien':
    print("Bienvenue monsieur le visiteur.")
elif nom == 'Marc':
    print("Bienvenue monsieur le développeur.")
else:
    print("Je ne vous connais pas monsieur.")

nom = None
nom = ''
nom = 'Nicolas'
if nom:
    print("Vous avez un nom.")
else:
    print("Vous n'avez pas de nom.")

bonbons = None
bonbons = 0
bonbons = 5
if bonbons:
    print("Donnez-moi un bonbon s'il vous plaît !")

print(bool(0))
print(bool(1))
print(bool(-1))
print(bool(''))
print(bool('abc'))
print(bool('True'))
print(bool('False'))  # True
print(bool(None))
print(bool(False))

nom = 'Paul'
if nom == 'Paul' or nom == 'Roman' or nom == 'Charles' or nom == 'François' or nom == 'Olivier' or nom == 'Luc':
    print("Bienvenue à la formation Python, " + nom)
else:
    print("Vous ne faites pas partie de cette formation, " + nom)

j_ai_paye_les_employes = False
argent = 10

# if j_ai_paye_les_employes == False and argent >= 5:
# if j_ai_paye_les_employes is False and argent >= 5:
if (not j_ai_paye_les_employes) and argent >= 5:
    print("Je dois et je peux payer les employés.")

if not j_ai_paye_les_employes:
    if argent >= 5:
        print("Je dois et je peux payer les employés.")

# Les boucles
# ===========

i = 0
while i < 10:
    print(i)
    # i = i + 1
    i += 1

argent = 123
while argent >= 12:
    print("Je paye un employé !")
    # argent = argent - 12
    argent -= 12
print("Je n'ai plus assez d'argent !")

# argent = 123
# while argent >= 12:
#     pass

# print("Boucle infinie :")
# while True:
#     print("Itération !")

# Les listes
# ==========

restaurants = list()  # liste vide
restaurants = []  # liste vide
restaurants = ["L'oncle Pom", "Le Yéti", "Aux délices du Liban", "Mc Donald's", "Quick", "KFC", "Burger King", "Flunch",
               "Chez Paolino", "La taverne bavaroise"]
print(restaurants)
print(restaurants[0])
print(restaurants[1])
print(restaurants[2])

print('=' * 70)

i = 0
while i < len(restaurants):
    print(i, restaurants[i])
    i += 1

for restaurant in restaurants:
    print(restaurant)

for i, restaurant in enumerate(restaurants):
    print(i, restaurant)

places = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]

for restaurant, chaises in zip(restaurants, places):
    print(restaurant, chaises)

liste = ['maison', 3, 4.1, False, None]

restaurants = ["L'oncle Pom", "Le Yéti", "Aux délices du Liban", "Mc Donald's", "Quick", "KFC", "Burger King", "Flunch",
               "Chez Paolino", "La taverne bavaroise"]

restaurants[2] = "La Belle Chaurienne"
# Les listes sont muables (mutable)
print(restaurants)

restaurants.append("Les abattoirs de Carmen")
print(restaurants)

restaurants.insert(2, "L'entrecôte")
print(restaurants)

dernier = restaurants.pop()
print(restaurants)
print(dernier)

premier = restaurants.pop(0)
print(restaurants)
print(premier)

print([1, 2, 3] + [4, 5, 6])  # concaténation

if 'Quick' in restaurants:
    print("Quick est bien présent dans la liste.")

a, b, c = [1, 2, 3]  # décomposition
print(a)
print(b)
print(c)

for restaurant in restaurants:
    print(restaurant)
    if restaurant == 'Quick':
        break

print('=' * 70)

for restaurant in restaurants:
    if restaurant == 'Quick':
        continue
    print(restaurant)

# Les range
# =========

for i in range(10):
    print(i)

print('=' * 70)

for i in range(1, 10):
    print(i)

print('=' * 70)

for i in range(1, 10, 2):
    print(i)

print('=' * 70)

for i in range(10, 1, -1):
    print(i)

print('=' * 70)

for i in range(1, 10, -1):
    print(i)

# Le slicing (tranchage) sur les listes
# =====================================

nombres = list(range(100))
print(nombres)
print(nombres[12])
print(nombres[5:10])  # slicing
print(nombres[90:])
print(nombres[:10])
print(nombres[24:75:5])
print(nombres[49::10])
print(nombres[90:-1])
print(nombres[9::-1])
print(nombres[::-1])
print(nombres[:])

# Itérer sur une chaîne de caractères
# ===================================

for caractere in 'abcdefgh':
    print(caractere)

phrase = "Hello zorld!"
caracteres = list(phrase)
print(caracteres)
caracteres[6] = 'W'
print(caracteres)
# phrase2 = '-'.join(caracteres)
phrase2 = ''.join(caracteres)
print(phrase2)

ligne = 'Dupont,Jacques,49,14 rue de la Paix,12345'
personne = ligne.split(',')
print(personne)
print(personne[2])

# Les tuples
# ==========

t = tuple()  # tuple vide
t = ()  # tuple vide
t = (1, 2, 3)
print(t)
print(t[0])
print(t[1])
print(t[2])
# t.append(4)  # AttributeError: 'tuple' object has no attribute 'append'
# t[1] = 5  # TypeError: 'tuple' object does not support item assignment
# Les tuples sont immuables (immutable)

a, b, c = t
print(a)
print(b)
print(c)

t = ('a')
print(t)
print(type(t))

t = ('a',)
print(t)
print(type(t))

a = (1, 2, 3)
for coordonnee in a:
    print(coordonnee)

plugins = ('database', 'xml', 'http')
if 'xml' in plugins:
    print("Plugin XML disponible.")

position = (49, 17, 5)  # page = 49, ligne = 17, mot = 5

print(1, 2, 3)

# Les dictionnaires
# =================

dictionnaire = dict()  # dictionnaire vide
dictionnaire = {}  # dictionnaire vide
dictionnaire['maison'] = 'house'
dictionnaire = dict(maison='house', chaise='chair', porte='door')
dictionnaire = {'maison': 'house', 'chaise': 'chair', 'porte': 'door'}
print(dictionnaire)
print(dictionnaire['maison'])
print(dictionnaire['chaise'])
print(dictionnaire['porte'])

dictionnaire['fenetre'] = 'window'
print(dictionnaire)

dictionnaire['maison'] = 'home'
print(dictionnaire)

del position
# print(position)  # NameError: name 'position' is not defined

del dictionnaire['fenetre']
print(dictionnaire)

print(dictionnaire.keys())
# for cle in dictionnaire.keys():
for cle in dictionnaire:
    print(cle, dictionnaire[cle])

print(dictionnaire.values())
for valeur in dictionnaire.values():
    print(valeur)

# for cle, valeur in dictionnaire.iteritems():  # Python 2.6
for cle, valeur in dictionnaire.items():
    print(cle, valeur)

# print(dictionnaire['table'])  # KeyError: 'table'
# if 'table' in dictionnaire.keys():
if 'table' in dictionnaire:
    print(dictionnaire['table'])

traduction = dictionnaire.get('table', '*** PAS DE TRADUCTION ***')
print(traduction)

personne = ['Dupont', 'Jacques', 49, '14 rue de la Paix', 12345]
print(personne[2])

personne = {'nom': 'Dupont', 'prenom': 'Jacques', 'age': 49, 'adresse': '14 rue de la Paix', 'code_postal': 12345}
print(personne['age'])

os = {'Luc': 'Linux Mint', 'Roman': 'Ubuntu', 'François': 'Ubuntu', 'Olivier': 'Ubuntu', 'Paul': 'Ubuntu',
      'Charles': 'Ubuntu'}
print(os['Roman'])

votes = {
    "L'oncle Pom": 9,
    "Aux délices du Liban": 3,
    "Le Yéti": 1
}

# Les fonctions
# =============


def deux():
    resultat = 1 + 1
    return resultat
    print("Ceci ne s'affiche jamais.")


r = deux()
print(r)


def plus_tard():
    pass


def addition(a, b):
    return a + b


print(addition(1, 2))


def souligner(texte):
    print(texte)
    print('=' * len(texte))


souligner("Un certain titre")
souligner("A plusieurs endroits de son programme")

# Un certain titre
# ================


def encadrer(texte):
    print('#' * (len(texte)+4))
    print('#', texte, '#')
    print('#' * (len(texte)+4))


encadrer("Texte encadré")

#################
# Texte encadré #
#################


def change(chaine, position, caractere):
    """
    Cette fonction sert à remplacer un caractère dans une chaîne de caractères.

    :param chaine: la chaîne en question
    :param position: position du caractère à remplacer
    :param caractere: caractère de remplacement
    :return: une chaîne avec le caractère remplacé
    """
    return chaine[:position] + caractere + chaine[position+1:]


phrase = "Hello zorld!"
phrase2 = change(phrase, 6, 'W')
print(phrase2)

# change("autre chaine", 5, 'a')
# change("bonjour", 3, 'b')

# Etape 1 :


def piscine(liste):
    return ', '.join(liste) + " vont à la piscine."


personnes = ['Jean', 'Paul', 'Sophie', 'Marc', 'Damien', 'Nicolas']
phrase = piscine(personnes)
print(phrase)  # Jean, Paul, Sophie, Marc, Damien, Nicolas vont à la piscine.

# Etape 2 :


def piscine2(liste=None):
    # if liste is None or len(liste) == 0:
    if not liste:
        return "Personne ne va à la piscine."
    if len(liste) == 1:
        return liste[0] + " va à la piscine tout seul."
    return ', '.join(liste[:-1]) + " et " + liste[-1] + " vont à la piscine."


personnes = ['Jean', 'Paul', 'Sophie', 'Marc', 'Damien', 'Nicolas']
phrase = piscine2(personnes)
print(phrase)  # Jean, Paul, Sophie, Marc, Damien et Nicolas vont à la piscine.

# Etape 3 :

personnes = ['Nicolas']
phrase = piscine2(personnes)
print(phrase)  # Nicolas va à la piscine tout seul.

# Etape 4 :

personnes = []
phrase = piscine2(personnes)
print(phrase)  # Personne ne va à la piscine.

# Etape 5 :

personnes = None
phrase = piscine2(personnes)
print(phrase)  # Personne ne va à la piscine.

# Etape 6 :

phrase = piscine2()
print(phrase)  # Personne ne va à la piscine.

# Retour multiple
# ===============


def multiple():
    return 1, "Un"


nombre, chaine = multiple()
print(nombre, chaine)

# Variables globales et locales
# =============================

resultat = 123  # resultat est une variable globale


def addition(a, b):
    resultat = a + b  # resultat une variable locale à la fonction
    return resultat


print(addition(2, 3))
print(resultat)

# Désigner les paramètres par leur nom
# ====================================


def division(dividende, diviseur=1):
    return dividende / diviseur


print(division(10, 3))
print(division(dividende=10, diviseur=3))
print(division(diviseur=3, dividende=10))
print(division(123))

# Paramètres par défaut
# =====================


def bonjour(verbose=False):
    if verbose:
        print("Je suis en train d'éxcuter la fonction bonjour()...")
    print("Bonjour !")


bonjour(False)
bonjour(True)
bonjour()

print("Quelque chose...", end='***')
print("Quelque chose...")
print(1, 2, 3, sep='-')

# Paramètres en nombre variable
# =============================


def somme(*nombres):  # * = opérateur splat
    total = 0
    for nombre in nombres:
        total += nombre
    return total


# r = somme([1, 2, 3])
# print(r)

r = somme(1, 2, 3, 4, 5, 6)
print(r)

r = somme(*[1, 2, 3])
print(r)

nombres = [1, 2, 3, 4, 5]
r = somme(*nombres)
print(r)


def affiche_recette(nom, **ingredients):
    print(nom)
    for ingredient, quantite in ingredients.items():
        print("- {} : {}".format(ingredient, quantite))


ingredients = {
    'farine': '1 kg',
    'levure': '2 kg',
    'eau': '3 L',
    'sel': '4 kg'
}

# affiche_recette('Pain', ingredients)
affiche_recette('Pain', farine='1 kg', levure='2 kg', eau='3 L', sel='4 kg')
affiche_recette('Pain', **ingredients)

f = affiche_recette
f('Gâteau au chocolat', chocolat='1 kg', beurre='2 kg')

print2 = print
print2("abc", 123, True, False, None)

# configuration(login='luc', password='parapluie')

# Les tris
# ========

nombres = [5, 7, 2, 3, 9, 4]
nombres.sort()
print(nombres)

fromages = ['Brie', 'Tomme de savoie', 'morbier', 'Munster', 'emmental', 'roquefort', 'brillat-savarin']
fromages_tries = sorted(fromages)
print(fromages_tries)
print(ord('B'))
print(ord('b'))
print('Brie'.lower())


# def representant(fromage):
#     return fromage.lower()


# fromages_tries = sorted(fromages, key=representant)
fromages_tries = sorted(fromages, key=lambda fromage: fromage.lower())
print(fromages_tries)

# f = lambda a, b: a + b
# print(f(3, 4))

fromages = [
    ('brie', 3.1),
    ('tomme de savoie', 8),
    ('morbier', 5.5),
    ('munster', 6),
    ('emmental', 2),
    ('roquefort', 6.5),
    ('brillat-savarin', 8.5)
]

fromages_tries = sorted(fromages, key=lambda t: t[1])
print(fromages_tries)

# Les mutables
# ============

# Mutables : list, dict
# Immutables : int, float, str, tuple

nombres = list(range(10))
nombres2 = list(range(10))
print(nombres)
print(nombres2)

print(nombres == nombres2)
print(nombres is nombres2)

nombres3 = nombres2
nombres3.append(10)
print(nombres3)
print(nombres2)

print(nombres3 == nombres2)
print(nombres3 is nombres2)
print(id(nombres))
print(id(nombres2))
print(id(nombres3))


def ajouter(element, liste):
    # liste2 = liste[:]
    # liste2 = list(liste)
    # liste2 = liste.copy()
    liste.append(element)
    return liste


l1 = [1, 2, 3]
l2 = ajouter(4, l1)
print(l2)
print(l1)
print(id(l2))
print(id(l1))

# List comprehension
# ==================

nombres = list(range(10))
print(nombres)
# nombres2 = list(map(lambda n: 2*n, nombres))
nombres2 = [2*n for n in nombres]
print(nombres2)

# pairs = list(filter(lambda n: n % 2 == 0, nombres))
pairs = [n for n in nombres if n % 2 == 0]
print(pairs)


# def init():
#     c = lire_configuration()
#     appliquer_configuration(c)
#
#     def f():
#         print("Bonjour")
#     f()
#
#
# def main():
#     init()
#     loop()
#     save()
#
#
# main()

# Les expressions régulières (expression rationnelles)
# ====================================================

import re  # regular expression

url = 'http://www.mon-site-web.fr:12345/repertoire1/repertoire2/fichier.html'

m = re.search('^(https?)://([a-z.0-9-]+)(?::(\d+))?(.*)$', url)
# ^ = début de chaîne
# () = capturer ce qu'il y a entre les parenthèses
# ? = l'élément précédent peut être absent ou présent
# [a-z.0-9-] = caractère alphabétique ou chiffre ou point ou tiret
# + = l'élément précédent plusieurs fois (au moins 1 fois)
# \d = digit = chiffre
# (?:) = parenthèses non-capturantes
# . = n'importe quel caractère
# * = l'élément précédent plusieurs fois (peut être 0 fois)
# $ = fin de chaîne
if m is not None:
    print(m)
    print(m.group(0))
    protocole = m.group(1)
    domaine = m.group(2)
    port = m.group(3)
    route = m.group(4)
    print("Protocole :", protocole)
    print("Domaine :", domaine)
    print("Port :", port)
    print("Route :", route)
else:
    print("*** Echec de l'analyse !")

# Les dates et heures
# ===================

from datetime import datetime, timedelta

maintenant = datetime.now()
print(maintenant)
print(maintenant.hour)
print(maintenant.minute)
print(maintenant.second)
print(maintenant.strftime('%d/%m/%Y'))

duree = timedelta(days=7)
semaine_prochaine = maintenant + duree
print(semaine_prochaine)
print(semaine_prochaine.strftime('%d/%m/%Y'))

duree2 = semaine_prochaine - maintenant
print(duree2)
print(duree2.days)

# Manipulation de fichiers
# ========================

f = open('fichier.txt', 'w', encoding='utf-8')  # w = write

f.write("Une chaîne de caractères dedans...\n")
f.write("Une autre chaîne de caractères dedans...\n")
f.write("Une troisième chaîne de caractères dedans...\n")
print("On peut aussi écrire dans un fichier avec la fonction print()", file=f)
print("Encore une autre ligne", file=f)

f.close()


def fonction():
    with open('fichier.txt', 'r', encoding='utf-8') as f:  # r = read
        for ligne in f:
            print(ligne, end='')
        # Le fichier est automatiquement fermé lorsque l'interpréteur quitte le bloc


fonction()

with open('fichier.txt', 'r', encoding='utf-8') as f:  # r = read
    tout = f.read()
    print(tout)

config = {
    'database': {
        'host': 'localhost',
        'port': 3366,
        'user': 'luc',
        'password': 'parapluie',
        'database': 'formation'
    },
    'author': None,
    'prod': False,
    'logging': {
        'level': 'WARNING',
        'output': [
            {
                'type': 'standard',
                'target': 'stderr'
            },
            {
                'type': 'file',
                'target': 'formation.log'
            }
        ]
    }
}

print(config['database']['password'])

import json

with open('config.json', 'w', encoding='utf-8') as f:
    json.dump(config, f, indent=4)

with open('config.json', 'r', encoding='utf-8') as f:
    config2 = json.load(f)

print(config2)
print(config2['database']['password'])

chaine_json = json.dumps(config)  # s = string
print(repr(chaine_json))

config3 = json.loads(chaine_json)  # s = string
print(config3)
print(config3['database']['password'])

import os

liste_noeuds = os.listdir('.')
print(liste_noeuds)

for noeud in liste_noeuds:
    # print(noeud)
    if os.path.isfile(noeud):
        print("Fichier :", noeud)
    elif os.path.isdir(noeud):
        print("Répertoire :", noeud)

with open('append_example.txt', 'a', encoding='utf-8') as f:
    f.write("J'ajoute quelque chose dans ce fichier.\n")

action = 'dsfsdf'


def lister():
    pass


def ajouter():
    pass


def lire():
    pass


def supprimer():
    pass


def erreur():
    print("*** Vous avez fait n'importe quoi !!!!!!")


switch = {
    'lister': lister,
    'ajouter': ajouter,
    'lire': lire,
    'supprimer': supprimer
}

f = switch.get(action, erreur)
f()

with open('fichier.txt', 'r+', encoding='utf-8') as f:
    f.seek(8)
    f.write('UN TRUC QUI SE VOIT !')
