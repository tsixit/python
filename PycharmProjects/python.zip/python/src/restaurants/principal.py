def run():
    print("Début du programme principal...")
