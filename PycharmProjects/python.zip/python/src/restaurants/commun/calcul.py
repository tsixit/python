def addition(a, b):
    return a + b


# from restaurants.principal import run
from ..principal import run
from .. import principal
