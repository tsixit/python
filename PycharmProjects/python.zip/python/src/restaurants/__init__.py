def affiche_restaurants():
    print("- L'oncle Pom")
    print("- Le Yéti")
    print("- Aux délices du Liban")


# from restaurants.commun.calcul import addition
# from commun.calcul import addition  # Python 2
from .commun.calcul import addition
